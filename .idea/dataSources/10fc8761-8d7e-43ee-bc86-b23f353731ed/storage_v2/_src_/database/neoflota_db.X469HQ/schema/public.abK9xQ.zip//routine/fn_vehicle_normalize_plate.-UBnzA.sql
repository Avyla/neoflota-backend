create function fn_vehicle_normalize_plate() returns trigger
    language plpgsql
as
$$
BEGIN
  NEW.plate := UPPER(NEW.plate);
  RETURN NEW;
END;
$$;

comment on function fn_vehicle_normalize_plate() is 'Normaliza la columna plate a MAYÚSCULAS en INSERT/UPDATE.';

alter function fn_vehicle_normalize_plate() owner to postgres;

