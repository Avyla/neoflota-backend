create function fn_touch_updated_at() returns trigger
    language plpgsql
as
$$
BEGIN
   NEW.updated_at = now();
   RETURN NEW;
END;
$$;

comment on function fn_touch_updated_at() is 'Actualiza automáticamente la columna updated_at con now() en operaciones UPDATE.';

alter function fn_touch_updated_at() owner to postgres;

